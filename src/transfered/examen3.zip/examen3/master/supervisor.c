#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/types.h>
#include <inttypes.h>
#include <malloc.h>
#include <string.h>

void to_worker1(const char* file_name)
{
    int fd=open(file_name,O_RDONLY,0600);
    char ch;
    while(read(fd,&ch,1))
    {
        printf("am citit carac %c",ch);
        if(ch>='a' && ch<='z' || ch>='A' && ch<='Z')
        {
            printf("Am scris 1 caracter in pipe,%c",ch);
            write(STDIN_FILENO, &ch, 1);
        }
    }
    close(fd);
}

void from_worker2(int* shm_map)
{
    int x, y;
    x=shm_map[0];
    y=shm_map[1];
    printf("Nr_voc: %d; nr_cons: %d\n",x,y);
}

int main(int argc, char ** argv)
{
    printf("hey from supervisor \n");
    if(argc != 2)
    {
        printf("Bad usage; exited with code 1");
        exit(1);
    }

    int shm_fd = shm_open("comunicare_decriptie", O_CREAT | O_RDWR, 0600);
    int *map = mmap(NULL,10,PROT_READ,MAP_SHARED,shm_fd,0);
    if(shm_fd == -1)
    {
        perror("Error at making shm file; exited with code 3");
        exit(3);
    }

    int pipe_fd[2];
    if(-1==pipe(pipe_fd))
    {
        perror("Error at creating pipe,exited with code 4");
        exit(4);
    }
    dup2(pipe_fd[1], STDIN_FILENO);
    close(pipe_fd[1]);
    close(pipe_fd[0]);

    pid_t pid=fork();
    if(pid==-1)
    {
        perror("Error at fork, exited with code 3");
        exit(3);
    }
    if(pid==0)
    {
        if(-1==execl("/home/ana/so/examen3/slaves/worker1","worker1",NULL))
        {
            perror("Error at execl, exited with code 5");
            exit(5);
        }
        to_worker1(argv[1]);

    }
    else
    {
        
        sleep(1);

        from_worker2(map);
        munmap(map, 10);
        shm_unlink("comunicare_decriptie");
        return 0;
    }
    
}