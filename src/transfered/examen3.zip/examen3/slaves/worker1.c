#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/types.h>
#include <inttypes.h>
#include <string.h>

void to_worker2(int fifo_fd)
{
    char ch;
    while(read(STDIN_FILENO, &ch, 1))
    {
        printf("%c din pipe\n", ch);
        if(ch>='a') ch=(ch-'a'+14)%26+'a';
        else ch=(ch-'A'+14)%26+'A';
        if(write(fifo_fd, &ch, 1)!=1)
        {
            perror("error writing, exited with code 2");
            exit(2);
        }
    }

}
int main(int argc, char** argv)
{
    printf("hey from worker 1\n");
    if(mkfifo("/home/ana/so/examen3/slaves/send_data", 0600) == -1)
    {
        perror("Error at making fifo; exited with code 4");
        exit(4);
    }
    int fifo_fd = open("/home/ana/so/examen3/slaves/send_data", O_WRONLY, 0600);
    if(fifo_fd == -1)
    {
        perror("Error opening fifo file; exited with code 1");
        exit(1);
    }

    to_worker2(fifo_fd);
    close(fifo_fd);
    return 0;
}