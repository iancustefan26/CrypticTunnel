#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <inttypes.h>
#include <string.h>
int vocala(char c)
{
    if(strchr("aeiouAEIOU",c))
        return 1;
    return 0;
}
void do_work(int* shm_map, int fifo_fd)
{
    int nr_voc=0;
    int nr_cons=0;
    char ch;
    while(read(fifo_fd, &ch, 1))
    {
        if(vocala(ch)) nr_voc++;
        else nr_cons++;
    }
    shm_map[0] = nr_voc;
    shm_map[1] = nr_cons;
    printf("Am scris in shm : %d %d\n", nr_voc, nr_cons);
    close(fifo_fd);
}

int main(int argc, char**argv)
{
    printf("hey from worker2\n");
    int shm_fd = shm_open("comunicare_decriptie", O_CREAT | O_RDWR, 0600);
    int* shm_map = mmap( NULL,10,PROT_WRITE,MAP_SHARED,shm_fd,0);
    ftruncate(shm_fd, 10);
    if(shm_map == MAP_FAILED)
    {
        perror("Map failed; exited with code 5");
        exit(5);
    }

    int fifo_fd = open("/home/ana/so/examen3/slaves/send_data", O_RDONLY, 0600);
    do_work(shm_map,fifo_fd);

    return 0;
}