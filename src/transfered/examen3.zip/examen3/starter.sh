#!/bin/bash

path="$(pwd)"

exec "$path/slaves/worker2" &

sleep 3

exec "$path/master/supervisor" "$path/input.txt"

exit 0